const counter=document.querySelectorAll('.counters');
const speed = 200;

counter.forEach(counters =>{
	const updateCount = () =>{
		const target = +counters.getAttribute('data-target');
		const count = +counters.innerText;

		const inc = target / speed;

		if(count < target) {
			counters.innerText = Math.ceil(count + inc);
			setTimeout(updateCount,1);
		} else {
			count.innerText = target;
		}
	}
	updateCount();
});